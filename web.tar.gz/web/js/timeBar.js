
function DrawEventChart(width, height) {

  var format = d3.time.format("%Y-%m-%d");
  var format2 = d3.time.format("%m-%d");
  var events = [
    {'name': 'News biennial conference', "start": "2015-07-14", "end": "2015-07-20", 'keywords': "UQ, Biennial Conference, News", "dist": "10,18,9"},
    {'name': 'food security #uqag', "start": "2015-07-20", "end": "2015-07-22", 'keywords': "UQ, Create Change, food security", "dist": "12,8,5"},
    {'name': 'CreateChange #qldscience', "start": "2015-07-22", "end": "2015-07-23", 'keywords': "UQ, Superbugs, Create Change", "dist": "17,6,7"},
    {"name": "Market @noelmengel", "start": "2015-07-23", "end": "2015-07-25", "keywords": "UQ, Marketing, Market", "dist": "19,5,6"}
  ];

  var time = {"start": "2015-07-14", "end": "2015-07-25"};


  var sampleData = [{"date":"2012-03-20","total":3},
    {"date":"2012-03-21","total":8},
    {"date":"2012-03-22","total":2},
    {"date":"2012-03-23","total":10},
    {"date":"2012-03-24","total":3},
    {"date":"2012-03-25","total":20},
    {"date":"2012-03-26","total":12}];

var margin = {top: 20, right: 20, bottom: 20, left:20};

var x = d3.time.scale()
    .domain([new Date(sampleData[0].date), d3.time.day.offset(new Date(sampleData[sampleData.length - 1].date), 1)])
    .rangeRound([0, width - margin.left - margin.right]);

var y = d3.scale.linear()
    .domain([0, d3.max(sampleData, function(d) { return d.total; })])
    .range([height - margin.top - margin.bottom, 0]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient('bottom')
    .ticks(d3.time.days, 1)
    .tickFormat(d3.time.format('%a %d'))
    .tickSize(0)
    .tickPadding(8);

var yAxis = d3.svg.axis()
    .scale(y)
    .orient('left')
    .tickPadding(8);


var svg = d3.select("#series_chart_div").append("svg")
    .attr('class', 'chart')
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");



//svg.selectAll('.chart')
 //   .data(sampleData)
 // .enter().append('rect')
   // .attr('class', 'bar')
   // .attr('x', function(d) { return x(new Date(d.date)); })
   // .attr('y', function(d) { return y(d.total); })
   // .attr('width', 10)
   // .attr('height', function(d) { return y(d.total); });


   svg.selectAll("circle").data(sampleData)
          .enter()
          .insert("circle")
          .attr("cx", function (d) {
            return  x(new Date(d.date));
          })
          .attr("cy", function (d) {
            return y(d.total);
          })
          .attr("r", 10)
          .style("fill", "red");

svg.append('g')
    .attr('class', 'x axis')
    .attr('transform', 'translate(0, ' + (height - margin.top - margin.bottom) + ')')
    .call(xAxis);

svg.append('g')
  .attr('class', 'y axis')
  .call(yAxis);

}